
<html>
    <head>
        <link rel="stylesheet" href="index.css">
        <div class="header"> <b>Delivery Service</b></div>
    </head>
    <body class = "bg">
    <br> <br> 
     <div class="box" align="center">
		<button class="bigButton" onclick="location.href='indexC.php'">Customer Login</button>
		<button class="bigButton" onclick="location.href='indexD.php'">Driver Login</button>
	</div>
	<br>
	<div class="box2" align="center">
		<button class="bigButton" onclick="location.href='createUser.php'">Create New Customer Account</button>
		<button class="bigButton" onclick="location.href='createDriver.php'">Create New Driver Account</button>
	</div>
    </body>
</html>
